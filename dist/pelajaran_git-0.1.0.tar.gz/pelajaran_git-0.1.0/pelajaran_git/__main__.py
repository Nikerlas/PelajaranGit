from .guess_number import guess_number


if __name__ == "__main__":
    guess_number()