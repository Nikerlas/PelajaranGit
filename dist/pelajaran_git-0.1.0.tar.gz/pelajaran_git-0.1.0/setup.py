from setuptools import setup, find_packages

setup(
    name= 'pelajaran_git',
    version='0.1.0',
    author='Nicholas',
    author_email='yyumireko@gmail.com',
    description='latihan pypi',
    packages=find_packages(),
    classifier=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent'
    ],
    python_requires='>=3.6',
)