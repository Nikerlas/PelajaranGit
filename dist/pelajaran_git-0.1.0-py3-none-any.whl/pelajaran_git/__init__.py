"""
pyexample.
An example python library.
"""

___version__ = "0.1.0"
__author__ = "Nicholas Ernesto"
__credits__ = "Politeknik Negeri Semarang"